// Function to load external scripts
console.log("-------------------starting project--------------------.");

function loadScript(url, callback) {
  const script = document.createElement('script');
  script.type = 'text/javascript';
  script.src = url;
  script.onload = callback;
  document.head.appendChild(script);
  console.log("-------------------reached at this point1--------------------.");
}

// Load Meyda and Tone.js scripts
loadScript('https://cdn.jsdelivr.net/npm/meyda/dist/web/meyda.min.js', () => {
  console.log("-------------------reached at this point2--------------------.");\
   
  console.log("Meyda loaded.");
  loadScript('https://cdn.jsdelivr.net/npm/tone', () => {
    console.log("Tone.js loaded.");
    //initialize();
  });
});

// Function to initialize the extension
function initialize() {
  console.log("Initializing extension...");

  // Wait for the YouTube video element to load
  const video = document.querySelector('video');
  if (!video) {
    console.error("No video element found on the page.");
    return;
  }

  console.log("Video element found.");

  // Create a visual overlay for feedback
  const overlay = document.createElement('div');
  overlay.style.position = 'fixed';
  overlay.style.top = '10px';
  overlay.style.left = '10px';
  overlay.style.padding = '10px';
  overlay.style.backgroundColor = 'rgba(0, 0, 0, 0.7)';
  overlay.style.color = 'white';
  overlay.style.zIndex = '10000';
  overlay.style.fontSize = '16px';
  overlay.innerText = 'Piano Tutor: Waiting for the correct note...';
  document.body.appendChild(overlay);

  // Set up Meyda for audio feature extraction
  const audioContext = new (window.AudioContext || window.webkitAudioContext)();
  let source;
  let analyzer;

  function setupAudio() {
    if (!source) {
      console.log("Setting up audio...");
      source = audioContext.createMediaElementSource(video);
      analyzer = Meyda.createMeydaAnalyzer({
        audioContext: audioContext,
        source: source,
        bufferSize: 512,
        featureExtractors: ['pitch'],
        callback: features => {
          const pitch = features.pitch;
          if (pitch) {
            const currentTime = video.currentTime;
            const note = pitchToMidi(pitch);
            console.log(`Current Time: ${currentTime}, Detected Note: ${note}`);
            // Add logic to create timestamp mapping and pause video
          } else {
            console.log("No pitch detected.");
          }
        }
      });
      console.log("Audio setup complete.");
    }
  }

  // Function to convert pitch to MIDI note number
  function pitchToMidi(pitch) {
    const A4 = 440;
    const A4_MIDI = 69;
    return Math.round(12 * (Math.log2(pitch / A4)) + A4_MIDI);
  }

  // MIDI Input Handling
  navigator.requestMIDIAccess().then((midiAccess) => {
    const inputs = midiAccess.inputs.values();
    for (let input of inputs) {
      input.onmidimessage = (message) => {
        const [status, note, velocity] = message.data;
        console.log(`MIDI Note: ${note}, Velocity: ${velocity}`);
        // Add logic to resume video if the correct note is played
      };
    }
  }).catch((err) => {
    console.error("Failed to access MIDI devices:", err);
    overlay.innerText = 'Piano Tutor: Failed to access MIDI devices.';
  });

  // Start Meyda analyzer
  video.addEventListener('play', () => {
    audioContext.resume().then(() => {
      console.log("Audio context resumed, starting analyzer.");
      setupAudio();
      analyzer.start();
    }).catch((err) => {
      console.error("Failed to resume audio context:", err);
    });
  });

  video.addEventListener('pause', () => {
    if (analyzer) {
      console.log("Video paused, stopping analyzer.");
      analyzer.stop();
    }
  });
}