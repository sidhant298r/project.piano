// popup.js

document.getElementById("start").addEventListener("click", () => {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    chrome.scripting.executeScript({
      target: { tabId: tabs[[0]](#).id },
      func: startPianoTutor
    });
  });
});

document.getElementById("stop").addEventListener("click", () => {
  document.getElementById("status").textContent = "Status: Stopped";
  console.log("Piano Tutor stopped.");
});

function startPianoTutor() {
  console.log("Piano Tutor started.");
  document.getElementById("status").textContent = "Status: Running";
}