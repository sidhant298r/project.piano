#piano-hit-line {
  position: fixed;
  bottom: 25%;
  left: 0;
  width: 100%;
  height: 3px;
  background: lime;
  z-index: 9999;
}
