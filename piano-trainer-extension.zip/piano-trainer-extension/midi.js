function initMIDI() {
  navigator.requestMIDIAccess().then(
    (access) => {
      console.log("🎹 MIDI access granted");

      for (const input of access.inputs.values()) {
        console.log("🎹 Connected:", input.name);
        input.onmidimessage = onMidiMessage;
      }
    },
    () => {
      console.error("❌ MIDI access denied");
    }
  );
}

function onMidiMessage(msg) {
  if (!window.waitingForNote) return;

  const [status, note, velocity] = msg.data;

  // Note ON
  if (status === 144 && velocity > 0) {
    console.log("🎹 Played:", note);

    if (note === window.expectedMidiNote) {
      console.log("✅ Correct note played");

      window.waitingForNote = false;
      window.expectedMidiNote = null;

      const video = document.querySelector("video");
      if (video) video.play();
    }
  }
}
