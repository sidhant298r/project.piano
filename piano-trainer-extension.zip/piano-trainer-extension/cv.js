window.waitingForNote = false;
window.expectedMidiNote = null;

const HIT_LINE_RATIO = 0.72; // Adjust if needed

function detectFallingBars(imageData, width, height, pauseCallback) {
  console.log("🎯 Bar detected at X:", x, "mapped note:", window.expectedMidiNote);
  if (window.waitingForNote) return;

  const data = imageData.data;
  const hitY = Math.floor(height * HIT_LINE_RATIO);

  for (let x = 0; x < width; x += 8) {
    const idx = (hitY * width + x) * 4;

    const r = data[idx];
    const g = data[idx + 1];
    const b = data[idx + 2];

    // Detect blue/cyan Synthesia bars
    if (b > 120 && g > 120 && r < 100) {
      window.expectedMidiNote = mapXToMidi(x, width);
      window.waitingForNote = true;
      pauseCallback();

      console.log("🎯 Waiting for MIDI note:", window.expectedMidiNote);
      return;
    }
  }
}

function mapXToMidi(x, width) {
  const TOTAL_KEYS = 88;
  const keyIndex = Math.floor((x / width) * TOTAL_KEYS);
  return 21 + keyIndex; // A0 = 21
}
